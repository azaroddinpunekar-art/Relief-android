package com.relief.app.data.ai

import com.relief.app.data.local.entity.PassageEntity

/**
 * Architectural contract for the future-ready RELIEF AI Wisdom Assistant.
 *
 * Strict Guardrails:
 * 1. Paid AI services MUST remain disabled until explicit user approval.
 * 2. Answers MUST retrieve and cite only verified passages stored in Room.
 * 3. AI-generated synthesis MUST be clearly separated from direct scripture quotations.
 * 4. If no verified passage matches a query, the assistant MUST report that honestly.
 */
data class WisdomAssistantResponse(
    val isServiceActive: Boolean,
    val citedPassages: List<PassageEntity>,
    val aiInterpretationDisclaimer: String,
    val comparativeExplanation: String,
    val errorOrNotice: String? = null
)

interface WisdomAssistantPort {
    val isPaidServiceEnabled: Boolean
    suspend fun answerLifeQuestion(question: String, verifiedCandidates: List<PassageEntity>): WisdomAssistantResponse
}

class OfflineGroundedWisdomAssistant(
    override val isPaidServiceEnabled: Boolean = false
) : WisdomAssistantPort {

    override suspend fun answerLifeQuestion(
        question: String,
        verifiedCandidates: List<PassageEntity>
    ): WisdomAssistantResponse {
        if (verifiedCandidates.isEmpty()) {
            return WisdomAssistantResponse(
                isServiceActive = isPaidServiceEnabled,
                citedPassages = emptyList(),
                aiInterpretationDisclaimer = "Verified Retrieval Guard",
                comparativeExplanation = "No verified passages in the local library matched your query. RELIEF will not fabricate verses or references.",
                errorOrNotice = "No matching verified passage found."
            )
        }

        if (!isPaidServiceEnabled) {
            return WisdomAssistantResponse(
                isServiceActive = false,
                citedPassages = verifiedCandidates.take(3),
                aiInterpretationDisclaimer = "Offline Verified Retrieval Mode — Paid AI synthesis is inactive pending explicit user approval.",
                comparativeExplanation = "Showing verified scripture references retrieved directly from your offline database. Enable the AI service in Settings only after reviewing API billing.",
                errorOrNotice = "AI synthesis paused until user approval."
            )
        }

        return WisdomAssistantResponse(
            isServiceActive = true,
            citedPassages = verifiedCandidates.take(3),
            aiInterpretationDisclaimer = "AI-assisted comparative reflection — NOT a direct religious ruling or scripture quotation.",
            comparativeExplanation = "Cross-tradition synthesis grounded strictly in the ${verifiedCandidates.size} verified passage(s) listed above."
        )
    }
}
