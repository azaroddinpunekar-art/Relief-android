package com.relief.app.data.repository

import android.content.Context
import android.net.Uri
import com.relief.app.data.ai.OfflineGroundedWisdomAssistant
import com.relief.app.data.ai.WisdomAssistantResponse
import com.relief.app.data.importer.ScriptureImporter
import com.relief.app.data.local.ReliefDatabase
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.BookmarkEntity
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.local.entity.ReadingHistoryEntity
import com.relief.app.data.model.ScriptureType
import com.relief.app.data.model.SituationCatalog
import com.relief.app.data.model.SituationGuidanceSpec
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate

class ReliefRepository(
    private val context: Context,
    private val database: ReliefDatabase
) {
    private val passageDao = database.passageDao()
    private val bookmarkDao = database.bookmarkDao()
    private val historyDao = database.historyDao()
    private val auditDao = database.importAuditDao()
    private val importer = ScriptureImporter(context, database)
    private val wisdomAssistant = OfflineGroundedWisdomAssistant(isPaidServiceEnabled = false)

    suspend fun initializeBundledDatasetsIfPresent() {
        importer.importFromAssetIfPresent(ScriptureType.QURAN, "quran.json")
        importer.importFromAssetIfPresent(ScriptureType.GITA, "gita.json")
        importer.importFromAssetIfPresent(ScriptureType.BIBLE, "bible.json")
    }

    suspend fun importDatasetFromUri(scripture: ScriptureType, uri: Uri): ImportAuditEntity {
        val stream = context.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Unable to open selected dataset file.")
        return stream.use { importer.importFromStream(scripture, it) }
    }

    fun observeBooks(scripture: ScriptureType): Flow<List<BookEntity>> =
        passageDao.observeBooks(scripture)

    fun observeChapter(scripture: ScriptureType, bookNumber: Int, chapterNumber: Int): Flow<List<PassageEntity>> =
        passageDao.observeChapterPassages(scripture, bookNumber, chapterNumber)

    fun observeBookmarks(): Flow<List<PassageEntity>> =
        bookmarkDao.observeBookmarkedPassages()

    fun observeBookmarkIds(): Flow<List<String>> =
        bookmarkDao.observeBookmarkIds()

    fun observeHistory(): Flow<List<PassageEntity>> =
        historyDao.observeRecentPassages()

    fun observeAudits(): Flow<List<ImportAuditEntity>> =
        auditDao.observeAudits()

    suspend fun toggleBookmark(passageId: String) {
        if (bookmarkDao.isBookmarked(passageId)) {
            bookmarkDao.deleteBookmark(passageId)
        } else {
            bookmarkDao.upsertBookmark(BookmarkEntity(passageId = passageId))
        }
    }

    suspend fun recordReading(passageId: String) {
        historyDao.recordView(ReadingHistoryEntity(passageId = passageId))
    }

    suspend fun clearReadingHistory() {
        historyDao.clearHistory()
    }

    suspend fun search(query: String, scripture: ScriptureType?): List<PassageEntity> {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return emptyList()
        return passageDao.searchPassages(trimmed, scripture)
    }

    suspend fun getPassagesForIds(ids: List<String>): Map<String, PassageEntity> {
        if (ids.isEmpty()) return emptyMap()
        return passageDao.getPassagesByIds(ids).associateBy { it.id }
    }

    suspend fun getDailyWisdom(): PassageEntity? {
        val total = passageDao.countAll()
        if (total == 0) return null
        val daySeed = LocalDate.now().toEpochDay().toInt().let { kotlin.math.abs(it) }
        return passageDao.getPassageAtOffset(daySeed % total)
    }

    fun getAllSituations(): List<SituationGuidanceSpec> = SituationCatalog.allSituations

    fun getSituationById(id: String): SituationGuidanceSpec? =
        SituationCatalog.allSituations.firstOrNull { it.id == id }

    suspend fun askWisdomAssistant(question: String): WisdomAssistantResponse {
        val candidates = search(question, null)
        return wisdomAssistant.answerLifeQuestion(question, candidates)
    }
}
