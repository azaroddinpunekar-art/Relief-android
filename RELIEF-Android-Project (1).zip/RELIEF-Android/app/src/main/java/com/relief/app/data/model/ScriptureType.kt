package com.relief.app.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ScriptureType(
    val displayNameEn: String,
    val displayNameHi: String,
    val originalLanguage: String,
    val isRtlOriginal: Boolean,
    val expectedBooksOrSurahs: Int,
    val expectedPassages: Int
) {
    QURAN(
        displayNameEn = "Quran",
        displayNameHi = "क़ुरआन",
        originalLanguage = "Arabic",
        isRtlOriginal = true,
        expectedBooksOrSurahs = 114,
        expectedPassages = 6236
    ),
    GITA(
        displayNameEn = "Bhagavad Gita",
        displayNameHi = "भगवद्गीता",
        originalLanguage = "Sanskrit",
        isRtlOriginal = false,
        expectedBooksOrSurahs = 18,
        expectedPassages = 700
    ),
    BIBLE(
        displayNameEn = "Bible",
        displayNameHi = "बाइबिल",
        originalLanguage = "Hebrew / Greek",
        isRtlOriginal = false,
        expectedBooksOrSurahs = 66,
        expectedPassages = 31102
    )
}

@Serializable
enum class AppLanguage(val code: String, val label: String, val nativeLabel: String) {
    ENGLISH("en", "English", "English"),
    HINDI("hi", "Hindi", "हिन्दी")
}
