package com.relief.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.data.preferences.UserSettings
import com.relief.app.ui.components.PassageCard
import com.relief.app.ui.components.ReliefCard
import com.relief.app.ui.components.ReliefTopBar
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.MutedGoldBorder
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.theme.WarmWhite

@Composable
fun BookmarksScreen(
    language: AppLanguage,
    fontScale: Float,
    bookmarks: List<PassageEntity>,
    onToggleBookmark: (String) -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "सहेजे गए वचन" else "Bookmarks") }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (bookmarks.isEmpty()) {
                item {
                    ReliefCard {
                        Text(
                            text = if (isHi) "अभी कोई बुकमार्क नहीं है" else "No Bookmarks Yet",
                            style = MaterialTheme.typography.titleMedium,
                            color = WarmWhite
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isHi) "पढ़ते समय किसी भी वचन को बुकमार्क करें।" else "Bookmark any passage while reading to return to it offline.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmGrey
                        )
                    }
                }
            } else {
                items(bookmarks, key = { it.id }) { passage ->
                    PassageCard(
                        passage = passage,
                        language = language,
                        fontScale = fontScale,
                        isBookmarked = true,
                        onToggleBookmark = { onToggleBookmark(passage.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun ReadingHistoryScreen(
    language: AppLanguage,
    fontScale: Float,
    history: List<PassageEntity>,
    bookmarkIds: List<String>,
    onToggleBookmark: (String) -> Unit,
    onClearHistory: () -> Unit,
    onBack: () -> Unit
) {
    val isHi = language == AppLanguage.HINDI
    Scaffold(
        containerColor = DeepObsidian,
        topBar = {
            ReliefTopBar(
                title = if (isHi) "पठन इतिहास" else "Reading History",
                onBack = onBack,
                actions = {
                    if (history.isNotEmpty()) {
                        OutlinedButton(
                            onClick = onClearHistory,
                            border = BorderStroke(1.dp, MutedGoldBorder),
                            modifier = Modifier.padding(end = 12.dp)
                        ) {
                            Text(if (isHi) "साफ़ करें" else "Clear", color = MetallicGold)
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (history.isEmpty()) {
                item {
                    ReliefCard {
                        Text(if (isHi) "पठन इतिहास खाली है" else "No Reading History", style = MaterialTheme.typography.titleMedium, color = WarmWhite)
                    }
                }
            } else {
                items(history, key = { it.id }) { passage ->
                    PassageCard(
                        passage = passage,
                        language = language,
                        fontScale = fontScale,
                        isBookmarked = bookmarkIds.contains(passage.id),
                        onToggleBookmark = { onToggleBookmark(passage.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProfileSettingsScreen(
    settings: UserSettings,
    importStatusMessage: String?,
    onSetLanguage: (AppLanguage) -> Unit,
    onSetFontScale: (Float) -> Unit,
    onSetTransliteration: (Boolean) -> Unit,
    onImportDataset: (ScriptureType, android.net.Uri) -> Unit,
    onOpenHistory: () -> Unit,
    onOpenAbout: () -> Unit
) {
    var pendingScripture by remember { mutableStateOf(ScriptureType.QURAN) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            onImportDataset(pendingScripture, uri)
        }
    }
    val isHi = settings.language == AppLanguage.HINDI

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "प्रोफ़ाइल और सेटिंग्स" else "Profile & Settings") }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ReliefCard {
                    Text(if (isHi) "भाषा वरीयता" else "Language Preference", style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppLanguage.entries.forEach { lang ->
                            OutlinedButton(
                                onClick = { onSetLanguage(lang) },
                                border = BorderStroke(1.dp, if (settings.language == lang) MetallicGold else MutedGoldBorder),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(lang.nativeLabel, color = if (settings.language == lang) MetallicGold else WarmWhite)
                            }
                        }
                    }
                }
            }

            item {
                ReliefCard {
                    Text(if (isHi) "फ़ॉन्ट आकार" else "Reading Typography Scale", style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Slider(
                        value = settings.fontScale,
                        onValueChange = onSetFontScale,
                        valueRange = 0.85f..1.4f,
                        colors = SliderDefaults.colors(thumbColor = MetallicGold, activeTrackColor = MetallicGold)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (isHi) "लिप्यंतरण दिखाएँ" else "Show Transliteration", color = WarmWhite)
                        Switch(checked = settings.showTransliteration, onCheckedChange = onSetTransliteration)
                    }
                }
            }

            item {
                ReliefCard {
                    Text("Offline Datasets (JSON Import)", style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Import validated public-domain datasets into local Room storage.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ScriptureType.entries.forEach { scripture ->
                            OutlinedButton(
                                onClick = {
                                    pendingScripture = scripture
                                    launcher.launch(arrayOf("application/json"))
                                },
                                modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, MutedGoldBorder)
                            ) {
                                Text("Import ${scripture.displayNameEn} JSON", color = WarmWhite)
                            }
                        }
                    }
                    if (!importStatusMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(importStatusMessage, style = MaterialTheme.typography.bodyMedium, color = MetallicGold)
                    }
                }
            }

            item {
                ReliefCard(onClick = onOpenHistory) {
                    Text(if (isHi) "पठन इतिहास देखें" else "Reading History", style = MaterialTheme.typography.titleMedium, color = WarmWhite)
                }
            }

            item {
                ReliefCard(onClick = onOpenAbout) {
                    Text(if (isHi) "स्रोत, लाइसेंस और डेटासेट सत्यापन" else "About, Sources & Validation Report", style = MaterialTheme.typography.titleMedium, color = WarmWhite)
                }
            }
        }
    }
}

@Composable
fun AboutSourcesScreen(
    audits: List<ImportAuditEntity>,
    onBack: () -> Unit
) {
    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = "About & Source Verification", onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                ReliefCard {
                    Text("RELIEF — Wisdom for Life's Struggles", style = MaterialTheme.typography.titleLarge, color = MetallicGold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Every scripture passage is stored locally in Room with source and license attribution. Editorial interpretations and practical reflections are strictly separated from primary texts.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )
                }
            }

            item {
                ReliefCard {
                    Text("Verified Public-Domain & Open Sources", style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Quran: Tanzil Uthmani Hafs (Arabic), Marmaduke Pickthall 1930 (English, Public Domain), Suhel Farooq Khan & Saifur Rahman Nadwi (Hindi).", style = MaterialTheme.typography.bodyMedium, color = WarmWhite)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• Bhagavad Gita: Sanskrit Devanagari Recension, Swami Sivananda (English), Swami Tejomayananda / Ramsukhdas (Hindi) via Vedic Scriptures GPL archive.", style = MaterialTheme.typography.bodyMedium, color = WarmWhite)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• Bible: King James Version 1769 (Public Domain), Westminster Leningrad Codex Hebrew OT (Public Domain), Textus Receptus Greek NT (Public Domain), Hindi IRV (CC-BY-SA 4.0).", style = MaterialTheme.typography.bodyMedium, color = WarmWhite)
                }
            }

            items(audits, key = { it.scripture.name }) { audit ->
                ReliefCard {
                    Text(
                        text = "${audit.scripture.displayNameEn} — ${if (audit.isComplete) "Complete" else "Incomplete"}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MetallicGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Books/Surahs: ${audit.importedBooksOrSurahs}/${audit.expectedBooksOrSurahs} · Passages: ${audit.importedPassages}/${audit.expectedPassages}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmWhite
                    )
                    Text(
                        text = "Original: ${audit.originalCoverage} · English: ${audit.englishCoverage} · Hindi: ${audit.hindiCoverage} · Duplicates rejected: ${audit.duplicateRejected}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(audit.missingRecordsSummary, style = MaterialTheme.typography.labelMedium, color = WarmGrey)
                }
            }
        }
    }
}
