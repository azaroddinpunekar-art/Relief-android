package com.relief.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.ui.graphics.vector.ImageVector

sealed class ReliefRoute(val route: String) {
    data object Splash : ReliefRoute("splash")
    data object Welcome : ReliefRoute("welcome")
    data object LanguageSelector : ReliefRoute("language_selector")
    data object Home : ReliefRoute("home")
    data object ScripturesHub : ReliefRoute("scriptures_hub")
    data object QuranLibrary : ReliefRoute("quran_library")
    data object GitaLibrary : ReliefRoute("gita_library")
    data object BibleLibrary : ReliefRoute("bible_library")
    data object Reader : ReliefRoute("reader/{scripture}/{bookNumber}/{chapterNumber}") {
        fun create(scripture: String, bookNumber: Int, chapterNumber: Int): String =
            "reader/$scripture/$bookNumber/$chapterNumber"
    }
    data object Situations : ReliefRoute("situations")
    data object SituationDetail : ReliefRoute("situation_detail/{situationId}") {
        fun create(situationId: String): String = "situation_detail/$situationId"
    }
    data object CrossReligiousComparison : ReliefRoute("comparison/{situationId}") {
        fun create(situationId: String): String = "comparison/$situationId"
    }
    data object Search : ReliefRoute("search")
    data object Bookmarks : ReliefRoute("bookmarks")
    data object ReadingHistory : ReliefRoute("reading_history")
    data object Profile : ReliefRoute("profile")
    data object AboutSources : ReliefRoute("about_sources")
}

enum class BottomNavTab(
    val route: String,
    val labelEn: String,
    val labelHi: String,
    val icon: ImageVector
) {
    HOME(ReliefRoute.Home.route, "Home", "होम", Icons.Outlined.Home),
    SCRIPTURES(ReliefRoute.ScripturesHub.route, "Scriptures", "ग्रंथ", Icons.Outlined.AutoStories),
    SITUATIONS(ReliefRoute.Situations.route, "Situations", "परिस्थितियाँ", Icons.Outlined.Psychology),
    BOOKMARKS(ReliefRoute.Bookmarks.route, "Bookmarks", "सहेजे गए", Icons.Outlined.BookmarkBorder),
    PROFILE(ReliefRoute.Profile.route, "Profile", "प्रोफ़ाइल", Icons.Outlined.PersonOutline)
}
