package com.relief.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.relief.app.ui.navigation.ReliefNavHost
import com.relief.app.ui.theme.ReliefTheme
import com.relief.app.ui.viewmodel.ReliefViewModel
import com.relief.app.ui.viewmodel.ReliefViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as ReliefApplication
        setContent {
            ReliefTheme {
                val reliefViewModel: ReliefViewModel = viewModel(
                    factory = ReliefViewModelFactory(app.reliefRepository, app.preferencesRepository)
                )
                ReliefNavHost(viewModel = reliefViewModel)
            }
        }
    }
}
