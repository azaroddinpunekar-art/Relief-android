package com.relief.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.relief.app.data.ai.WisdomAssistantResponse
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.AppLanguage
import com.relief.app.data.model.ScriptureType
import com.relief.app.data.model.SituationGuidanceSpec
import com.relief.app.ui.components.PassageCard
import com.relief.app.ui.components.ReliefCard
import com.relief.app.ui.components.ReliefTopBar
import com.relief.app.ui.theme.CharcoalSurface
import com.relief.app.ui.theme.DeepObsidian
import com.relief.app.ui.theme.MetallicGold
import com.relief.app.ui.theme.MutedGoldBorder
import com.relief.app.ui.theme.WarmGrey
import com.relief.app.ui.theme.WarmWhite

@Composable
fun LifeSituationsScreen(
    language: AppLanguage,
    situations: List<SituationGuidanceSpec>,
    onSelectSituation: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val isHi = language == AppLanguage.HINDI
    val filtered = remember(query, situations) {
        if (query.isBlank()) situations
        else situations.filter {
            it.titleEn.contains(query, ignoreCase = true) ||
                it.titleHi.contains(query, ignoreCase = true) ||
                it.subtitleEn.contains(query, ignoreCase = true)
        }
    }

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "जीवन की परिस्थितियाँ" else "Life Situations") }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(if (isHi) "परिस्थिति खोजें..." else "Search struggles (anger, grief, anxiety)...") }
                )
            }
            items(filtered, key = { it.id }) { spec ->
                ReliefCard(onClick = { onSelectSituation(spec.id) }) {
                    Text(
                        text = if (isHi) spec.titleHi else spec.titleEn,
                        style = MaterialTheme.typography.titleMedium,
                        color = WarmWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHi) spec.subtitleHi else spec.subtitleEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )
                }
            }
        }
    }
}

@Composable
fun SituationDetailScreen(
    spec: SituationGuidanceSpec,
    language: AppLanguage,
    fontScale: Float,
    bookmarkIds: List<String>,
    loadPassages: suspend (List<String>) -> Map<String, PassageEntity>,
    onToggleBookmark: (String) -> Unit,
    onOpenComparison: (String) -> Unit,
    onBack: () -> Unit
) {
    var passageMap by remember(spec.id) { mutableStateOf<Map<String, PassageEntity>>(emptyMap()) }
    val isHi = language == AppLanguage.HINDI

    LaunchedEffect(spec.id) {
        passageMap = loadPassages(spec.passageMappings.map { it.passageId })
    }

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) spec.titleHi else spec.titleEn, onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = if (isHi) spec.subtitleHi else spec.subtitleEn,
                    style = MaterialTheme.typography.bodyLarge,
                    color = WarmGrey
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onOpenComparison(spec.id) },
                    border = BorderStroke(1.dp, MutedGoldBorder)
                ) {
                    Text(if (isHi) "तीन ग्रंथों की तुलना देखें" else "Compare Across All Three Traditions", color = MetallicGold)
                }
            }

            items(spec.passageMappings) { mapping ->
                val passage = passageMap[mapping.passageId]
                ReliefCard {
                    Text(
                        text = "${mapping.scripture.displayNameEn} · ${mapping.passageId}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MetallicGold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (passage != null) {
                        Text("A. Original Scripture", style = MaterialTheme.typography.labelMedium, color = WarmGrey)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(passage.originalText, style = MaterialTheme.typography.titleMedium, color = WarmWhite)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("B. Verified Translation", style = MaterialTheme.typography.labelMedium, color = WarmGrey)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isHi && passage.hindiText.isNotBlank()) passage.hindiText else passage.englishText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmWhite
                        )
                    } else {
                        Text(
                            text = "A & B. Verified passage ${mapping.passageId} awaiting dataset import in Offline Datasets.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarmGrey
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("C. Interpretation", style = MaterialTheme.typography.labelMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHi) mapping.interpretationHi else mapping.interpretationEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmGrey
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("D. Practical Reflection", style = MaterialTheme.typography.labelMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isHi) mapping.reflectionHi else mapping.reflectionEn,
                        style = MaterialTheme.typography.bodyMedium,
                        color = WarmWhite
                    )
                }
            }
        }
    }
}

@Composable
fun CrossReligiousComparisonScreen(
    spec: SituationGuidanceSpec,
    language: AppLanguage,
    loadPassages: suspend (List<String>) -> Map<String, PassageEntity>,
    onBack: () -> Unit
) {
    var passageMap by remember(spec.id) { mutableStateOf<Map<String, PassageEntity>>(emptyMap()) }
    val isHi = language == AppLanguage.HINDI

    LaunchedEffect(spec.id) {
        passageMap = loadPassages(spec.passageMappings.map { it.passageId })
    }

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "तुलनात्मक अध्ययन" else "Cross-Religious Comparison", onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = if (isHi) spec.titleHi else spec.titleEn,
                    style = MaterialTheme.typography.headlineMedium,
                    color = WarmWhite
                )
                Text(
                    text = "Comparing verified primary texts alongside clearly separated commentary.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = WarmGrey
                )
            }
            items(spec.passageMappings) { mapping ->
                val passage = passageMap[mapping.passageId]
                ReliefCard {
                    Text(mapping.scripture.displayNameEn, style = MaterialTheme.typography.titleMedium, color = MetallicGold)
                    Spacer(modifier = Modifier.height(6.dp))
                    if (passage != null) {
                        Text(
                            text = if (isHi && passage.hindiText.isNotBlank()) passage.hindiText else passage.englishText,
                            style = MaterialTheme.typography.bodyLarge,
                            color = WarmWhite
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(passage.translationEdition, style = MaterialTheme.typography.labelMedium, color = WarmGrey)
                    } else {
                        Text("Reference ${mapping.passageId} · Import dataset to display verbatim text.", color = WarmGrey)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(if (isHi) mapping.interpretationHi else mapping.interpretationEn, style = MaterialTheme.typography.bodyMedium, color = WarmGrey)
                }
            }
        }
    }
}

@Composable
fun UniversalSearchScreen(
    language: AppLanguage,
    fontScale: Float,
    results: List<PassageEntity>,
    bookmarkIds: List<String>,
    assistantResponse: WisdomAssistantResponse?,
    onSearch: (String, ScriptureType?) -> Unit,
    onAskAssistant: (String) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf<ScriptureType?>(null) }
    val isHi = language == AppLanguage.HINDI

    Scaffold(
        containerColor = DeepObsidian,
        topBar = { ReliefTopBar(title = if (isHi) "सार्वभौमिक खोज" else "Universal Search", onBack = onBack) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onSearch(it, selectedFilter)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    placeholder = { Text(if (isHi) "शब्द, ग्रंथ या संदर्भ खोजें..." else "Keyword, book, or reference (e.g. patience, 2:286)...") }
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedFilter == null,
                        onClick = { selectedFilter = null; onSearch(query, null) },
                        label = { Text("All") },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CharcoalSurface)
                    )
                    ScriptureType.entries.forEach { st ->
                        FilterChip(
                            selected = selectedFilter == st,
                            onClick = { selectedFilter = st; onSearch(query, st) },
                            label = { Text(st.displayNameEn) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = CharcoalSurface)
                        )
                    }
                }
            }

            if (query.isNotBlank()) {
                item {
                    OutlinedButton(
                        onClick = { onAskAssistant(query) },
                        border = BorderStroke(1.dp, MutedGoldBorder)
                    ) {
                        Text("Run Grounded Wisdom Check (Offline Guard)", color = MetallicGold)
                    }
                }
            }

            if (assistantResponse != null) {
                item {
                    ReliefCard {
                        Text(assistantResponse.aiInterpretationDisclaimer, style = MaterialTheme.typography.labelMedium, color = MetallicGold)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(assistantResponse.comparativeExplanation, style = MaterialTheme.typography.bodyMedium, color = WarmWhite)
                    }
                }
            }

            items(results, key = { it.id }) { passage ->
                PassageCard(
                    passage = passage,
                    language = language,
                    fontScale = fontScale,
                    isBookmarked = bookmarkIds.contains(passage.id),
                    onToggleBookmark = { onToggleBookmark(passage.id) }
                )
            }
        }
    }
}
