package com.relief.app.data.importer

import android.content.Context
import com.relief.app.data.local.ReliefDatabase
import com.relief.app.data.local.entity.BookEntity
import com.relief.app.data.local.entity.ImportAuditEntity
import com.relief.app.data.local.entity.PassageEntity
import com.relief.app.data.model.ScriptureType
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.InputStream

@Serializable
data class ImportBundleDto(
    val books: List<ImportBookDto> = emptyList(),
    val passages: List<ImportPassageDto> = emptyList()
)

@Serializable
data class ImportBookDto(
    val scripture: ScriptureType,
    val bookNumber: Int,
    val nameEnglish: String,
    val nameOriginal: String,
    val nameHindi: String,
    val revelationOrSection: String = "",
    val chapterCount: Int = 1,
    val expectedVerseCount: Int = 0
)

@Serializable
data class ImportPassageDto(
    val id: String,
    val scripture: ScriptureType,
    val bookNumber: Int,
    val bookOrSurah: String,
    val bookOrSurahOriginal: String = "",
    val bookOrSurahHindi: String = "",
    val chapterNumber: Int,
    val verseNumber: Int,
    val originalText: String,
    val transliteration: String = "",
    val englishText: String,
    val hindiText: String,
    val translationEdition: String,
    val source: String,
    val license: String
)

data class ValidationResult(
    val scripture: ScriptureType,
    val acceptedPassages: List<PassageEntity>,
    val acceptedBooks: List<BookEntity>,
    val duplicateCount: Int,
    val missingRecords: List<String>,
    val isComplete: Boolean
)

object DatasetValidator {
    fun validate(scripture: ScriptureType, bundle: ImportBundleDto): ValidationResult {
        val seenIds = HashSet<String>()
        val seenCoordinates = HashSet<String>()
        val validPassages = ArrayList<PassageEntity>(bundle.passages.size)
        val missingRecords = ArrayList<String>()
        var duplicates = 0

        for (dto in bundle.passages) {
            if (dto.scripture != scripture) continue
            val coord = "${dto.scripture.name}:${dto.bookNumber}:${dto.chapterNumber}:${dto.verseNumber}"
            if (!seenIds.add(dto.id) || !seenCoordinates.add(coord)) {
                duplicates++
                continue
            }
            if (dto.englishText.isBlank() || dto.hindiText.isBlank() || dto.originalText.isBlank()) {
                missingRecords.add("${dto.id} missing translation or original text")
            }
            validPassages.add(
                PassageEntity(
                    id = dto.id,
                    scripture = dto.scripture,
                    bookNumber = dto.bookNumber,
                    bookOrSurah = dto.bookOrSurah,
                    bookOrSurahOriginal = dto.bookOrSurahOriginal,
                    bookOrSurahHindi = dto.bookOrSurahHindi,
                    chapterNumber = dto.chapterNumber,
                    verseNumber = dto.verseNumber,
                    originalText = dto.originalText,
                    transliteration = dto.transliteration,
                    englishText = dto.englishText,
                    hindiText = dto.hindiText,
                    translationEdition = dto.translationEdition,
                    source = dto.source,
                    license = dto.license
                )
            )
        }

        val countByBook = validPassages.groupingBy { it.bookNumber }.eachCount()
        val books = bundle.books
            .filter { it.scripture == scripture }
            .distinctBy { it.bookNumber }
            .map { b ->
                val imported = countByBook[b.bookNumber] ?: 0
                if (b.expectedVerseCount > 0 && imported < b.expectedVerseCount) {
                    missingRecords.add("${b.nameEnglish}: $imported/${b.expectedVerseCount} verses")
                }
                BookEntity(
                    id = "${scripture.name}:${b.bookNumber}",
                    scripture = scripture,
                    bookNumber = b.bookNumber,
                    nameEnglish = b.nameEnglish,
                    nameOriginal = b.nameOriginal,
                    nameHindi = b.nameHindi,
                    sectionOrType = b.revelationOrSection,
                    chapterCount = b.chapterCount,
                    expectedVerseCount = b.expectedVerseCount,
                    importedVerseCount = imported
                )
            }

        if (books.size < scripture.expectedBooksOrSurahs) {
            missingRecords.add("Books/Surahs count ${books.size}/${scripture.expectedBooksOrSurahs}")
        }
        if (validPassages.size < scripture.expectedPassages) {
            missingRecords.add("Passages count ${validPassages.size}/${scripture.expectedPassages}")
        }

        val isComplete = books.size >= scripture.expectedBooksOrSurahs &&
            validPassages.size >= scripture.expectedPassages &&
            missingRecords.isEmpty() &&
            duplicates == 0

        return ValidationResult(
            scripture = scripture,
            acceptedPassages = validPassages,
            acceptedBooks = books,
            duplicateCount = duplicates,
            missingRecords = missingRecords,
            isComplete = isComplete
        )
    }
}

class ScriptureImporter(
    private val context: Context,
    private val database: ReliefDatabase
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun importFromAssetIfPresent(scripture: ScriptureType, assetFileName: String): ImportAuditEntity {
        val stream = runCatching { context.assets.open("scriptures/$assetFileName") }.getOrNull()
        return if (stream != null) {
            stream.use { importFromStream(scripture, it) }
        } else {
            val existingCount = database.passageDao().countByScripture(scripture)
            val audit = ImportAuditEntity(
                scripture = scripture,
                expectedBooksOrSurahs = scripture.expectedBooksOrSurahs,
                importedBooksOrSurahs = 0,
                expectedPassages = scripture.expectedPassages,
                importedPassages = existingCount,
                originalCoverage = existingCount,
                englishCoverage = existingCount,
                hindiCoverage = existingCount,
                duplicateRejected = 0,
                isComplete = false,
                missingRecordsSummary = "Dataset bundle scriptures/$assetFileName not yet imported.",
                updatedAtEpochMs = System.currentTimeMillis()
            )
            database.importAuditDao().upsertAudit(audit)
            audit
        }
    }

    suspend fun importFromStream(scripture: ScriptureType, inputStream: InputStream): ImportAuditEntity {
        val rawText = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val bundle = json.decodeFromString<ImportBundleDto>(rawText)
        val result = DatasetValidator.validate(scripture, bundle)

        database.passageDao().insertBooks(result.acceptedBooks)
        result.acceptedPassages.chunked(500).forEach { chunk ->
            database.passageDao().insertPassages(chunk)
        }

        val audit = ImportAuditEntity(
            scripture = scripture,
            expectedBooksOrSurahs = scripture.expectedBooksOrSurahs,
            importedBooksOrSurahs = result.acceptedBooks.size,
            expectedPassages = scripture.expectedPassages,
            importedPassages = result.acceptedPassages.size,
            originalCoverage = result.acceptedPassages.count { it.originalText.isNotBlank() },
            englishCoverage = result.acceptedPassages.count { it.englishText.isNotBlank() },
            hindiCoverage = result.acceptedPassages.count { it.hindiText.isNotBlank() },
            duplicateRejected = result.duplicateCount,
            isComplete = result.isComplete,
            missingRecordsSummary = if (result.missingRecords.isEmpty()) {
                "All canonical records verified."
            } else {
                result.missingRecords.take(25).joinToString("\n")
            },
            updatedAtEpochMs = System.currentTimeMillis()
        )
        database.importAuditDao().upsertAudit(audit)
        return audit
    }
}
