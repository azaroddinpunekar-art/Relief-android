package com.relief.app

import com.relief.app.data.importer.DatasetValidator
import com.relief.app.data.importer.ImportBookDto
import com.relief.app.data.importer.ImportBundleDto
import com.relief.app.data.importer.ImportPassageDto
import com.relief.app.data.model.ScriptureType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DatasetValidatorTest {

    @Test
    fun `validator rejects duplicate coordinates and reports incomplete canonical counts`() {
        val bundle = ImportBundleDto(
            books = listOf(
                ImportBookDto(
                    scripture = ScriptureType.QURAN,
                    bookNumber = 1,
                    nameEnglish = "Al-Fatihah",
                    nameOriginal = "الفاتحة",
                    nameHindi = "अल-फ़ातिहा",
                    chapterCount = 1,
                    expectedVerseCount = 7
                )
            ),
            passages = listOf(
                ImportPassageDto(
                    id = "QURAN:1:1",
                    scripture = ScriptureType.QURAN,
                    bookNumber = 1,
                    bookOrSurah = "Al-Fatihah",
                    chapterNumber = 1,
                    verseNumber = 1,
                    originalText = "بِسْمِ ٱللَّهِ ٱلرَّحْمَـٰنِ ٱلرَّحِيمِ",
                    englishText = "In the name of Allah, the Beneficent, the Merciful.",
                    hindiText = "अल्लाह के नाम से जो बड़ा कृपालु, अत्यन्त दयावान है।",
                    translationEdition = "Pickthall",
                    source = "Tanzil",
                    license = "Public Domain"
                ),
                ImportPassageDto(
                    id = "QURAN:1:1_DUP",
                    scripture = ScriptureType.QURAN,
                    bookNumber = 1,
                    bookOrSurah = "Al-Fatihah",
                    chapterNumber = 1,
                    verseNumber = 1,
                    originalText = "duplicate",
                    englishText = "duplicate",
                    hindiText = "duplicate",
                    translationEdition = "Pickthall",
                    source = "Tanzil",
                    license = "Public Domain"
                )
            )
        )

        val result = DatasetValidator.validate(ScriptureType.QURAN, bundle)
        assertEquals(1, result.acceptedPassages.size)
        assertEquals(1, result.duplicateCount)
        assertFalse(result.isComplete)
        assertTrue(result.missingRecords.any { it.contains("6236") })
    }
}
